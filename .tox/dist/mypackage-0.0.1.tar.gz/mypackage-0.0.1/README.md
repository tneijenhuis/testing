# This is a test package with the aim to learn automated testing
