import numpy as np


def put_in_array(a, b, c):
    return np.array([a, b, c])


def transpose_matrix(matrix):
    return matrix.transpose()
